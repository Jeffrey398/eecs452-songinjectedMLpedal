# URL to Electric Guitar

A command-line Python pipeline that downloads audio from a URL, converts it to WAV, uploads it to LALAL.AI, requests the electric-guitar stem, and saves the result as a 16-bit PCM WAV. Local audio/video files are also supported.

```text
URL → yt-dlp → FFmpeg WAV → LALAL.AI → electric_guitar.wav
```

This is a standalone implementation of the previously discussed pipeline. Separation runs on LALAL.AI's servers and uses your account's processing allowance. The output contains the guitar tone already present in the song; it is not a clean DI recording. Only process audio you have permission to download and use.

## 1. Install prerequisites

- Python 3.10 or newer from https://www.python.org/downloads/ (enable Add Python to PATH on Windows).
- FFmpeg and FFprobe on PATH: https://ffmpeg.org/download.html . On Windows, `winget install --id Gyan.FFmpeg --exact` is one installation option. Restart your terminal afterward.
- A LALAL.AI API license key and sufficient processing allowance.
- For YouTube, yt-dlp recommends a supported JavaScript runtime such as Deno: https://deno.com/ . Other sites and local files may not need it.

Check installation:

```powershell
python --version
ffmpeg -version
ffprobe -version
```

From this repository's folder, create a virtual environment and install dependencies.

Windows PowerShell (activation is not required):

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

macOS/Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
```

## 2. Obtain and configure the API key

Start at the [official LALAL.AI API page](https://www.lalal.ai/api/). Sign in and obtain API access and a license key for your account. If your account does not expose a key, contact LALAL.AI support from that page. Confirm API access and allowance; do not assume a website subscription includes it.

The program reads `LALAL_API_KEY` from the environment. It never stores the key in source code or output files, and it does not automatically load `.env` files.

Windows PowerShell — set it for the current terminal without putting the key in command history:

```powershell
$secret = Read-Host 'LALAL.AI API key' -AsSecureString
$env:LALAL_API_KEY = [System.Net.NetworkCredential]::new('', $secret).Password
Remove-Variable secret
```

Run the pipeline in that same terminal. To persist the key for your Windows user, use **Edit environment variables for your account → User variables → New**, name it `LALAL_API_KEY`, paste the key as the value, then open a new terminal. Environment variables are not a credential vault; other processes under your account can read them.

macOS/Linux (Bash) — current terminal only:

```bash
read -rsp 'LALAL.AI API key: ' LALAL_API_KEY; echo
export LALAL_API_KEY
```

Never commit your actual key. `.gitignore` excludes `.env` files and `*.key` files, but cannot protect a key pasted into tracked source or documentation. Revoke and replace a key if it is published.

## Fast minutes versus unlimited (Relaxed) mode

**There is no user-selectable unlimited/Relaxed mode in this client or a documented queue-selection parameter in the public separation API. The script cannot guarantee that a run will avoid consuming Fast minutes.**

LALAL.AI's [official FAQ](https://www.lalal.ai/guides/faq/) states that users cannot manually switch queues: processing uses Fast minutes first, then automatically switches to Relaxed processing after the Fast allowance is exhausted. Eligible subscriptions include unlimited Relaxed processing; availability depends on your account and API entitlement. This is server-side account behavior, not a Python setting.

Before relying on unlimited processing:

1. Check your subscription and remaining Fast minutes in your LALAL.AI profile.
2. Confirm that your license includes API access and that Relaxed processing applies to API requests under your plan. The public API schema does not itself guarantee this entitlement; ask LALAL.AI support if unclear.
3. Use the normal command below. There is no `--unlimited`, `--relaxed`, or `--fast` flag. If preserving your remaining Fast minutes is a requirement, this client cannot enforce it; do not submit a new separation assuming it will bypass them.

`splitter: "auto"` in the code selects the separation model, not the billing or processing queue. Likewise, `--timeout` only controls how long the client polls; it does not select Relaxed mode. For longer queue waits, increase it, for example `--timeout 7200`, or resume the existing task with `--task-id` rather than submitting another separation.

Verified against the FAQ and [public API specification](https://www.lalal.ai/api/v1/openapi.json) on November 27, 2026. No account-specific queue behavior has been tested with a live API key.

## 3. Run

Windows PowerShell, using a song/video URL:

```powershell
.\.venv\Scripts\python.exe guitar_pipeline.py --url "https://www.youtube.com/watch?v=VIDEO_ID" --output "outputs/my-song-guitar.wav"
```

Or use an existing audio file:

```powershell
.\.venv\Scripts\python.exe guitar_pipeline.py --input "C:\Music\song.mp3" --output "outputs/my-song-guitar.wav"
```

macOS/Linux:

```bash
.venv/bin/python guitar_pipeline.py --url "https://www.youtube.com/watch?v=VIDEO_ID" --output outputs/my-song-guitar.wav
```

Replace the example URL with your actual media URL. URLs must be supported by yt-dlp; DRM-protected streams and arbitrary music-service share links are not guaranteed to work. Playlists are disabled. Files are converted locally before upload; allow temporary disk space for uncompressed audio.

The default output is `outputs/electric_guitar.wav`. Existing output files are never overwritten. Intermediate downloads are removed when the program exits normally or handles an error. A forcibly killed process can leave a `.guitar-*` temporary directory.

### Resume a submitted task

The program prints a task ID immediately after submission. Save it. If polling or downloading fails, resume without uploading or paying for a new separation:

```powershell
.\.venv\Scripts\python.exe guitar_pipeline.py --task-id "YOUR_TASK_ID" --output "outputs/my-song-guitar.wav" --timeout 3600
```

The polling deadline defaults to 1,800 seconds; an individual in-flight network request can extend the elapsed time. Stopping the script or timing out does not cancel the remote task. According to the API documentation, completed tasks remain queryable for 24 hours; download promptly. The script does not delete the source from LALAL.AI storage. Remote expiration follows the service's policy.

If the submission request itself loses its response, the task may have started without returning its ID. Do not repeatedly resubmit blindly; check your account/support first.

## Troubleshooting

- **Missing API key:** set `LALAL_API_KEY` in the same terminal that launches Python.
- **HTTP 403 / API rejection:** check the key, API access, balance, and service limits.
- **Download failure:** check that the URL is accessible, install Deno for YouTube, or update with `python -m pip install --upgrade "yt-dlp[default]"` using your virtual environment's Python. A local file via `--input` skips yt-dlp.
- **FFmpeg missing:** reopen the terminal after installation and verify `ffmpeg -version`.
- **Task expired:** resume promptly; an expired task may require a new upload and separation.
- **Output exists:** choose a new filename.
- **Audio bleed:** separation quality depends on the mix; inspect the resulting stem before using it for tone analysis.

## Tests

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Tests use simulated API responses and a small synthetic WAV for local conversion. They do not contact LALAL.AI or spend processing credits. The FFmpeg integration test skips when FFmpeg is unavailable. Live separation requires your own key and has not been verified as part of packaging.

## Upload to a Git repository

Use the supplied ZIP or copy **this folder's contents** into a new standalone folder or an existing repository checkout. Include hidden `.gitignore`; do not copy the surrounding guitar-pedal project. For a new repository, create an empty remote repository, then run from the standalone folder:

```bash
git init -b main
git add .gitignore README.md requirements.txt guitar_pipeline.py tests
git status --short
git diff --cached
git commit -m "Add URL-to-electric-guitar pipeline"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

Replace the remote URL. Review staged files before committing. No API key or downloaded audio is needed in Git. This package has not been pushed to any remote repository.

## API references

Request fields and result selection were checked against the [official OpenAPI specification](https://www.lalal.ai/api/v1/openapi.json) and [API documentation](https://www.lalal.ai/api/v1/docs/) on November 27, 2026. The client uses `upload/`, `split/stem_separator/`, and `check/`, then selects the result with type `stem` and label `electric_guitar`. Media downloads do not receive the license header.

Downloader setup: [yt-dlp documentation](https://github.com/yt-dlp/yt-dlp#installation).
