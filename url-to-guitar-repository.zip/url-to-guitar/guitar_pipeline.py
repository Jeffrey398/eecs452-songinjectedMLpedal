"""Download a song, separate electric guitar with LALAL.AI, and save a WAV."""

import argparse
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen, HTTPRedirectHandler, build_opener

API = "https://www.lalal.ai/api/v1/"


class PipelineError(Exception):
    pass


class NoRedirect(HTTPRedirectHandler):
    # Never forward the license header to a redirected host.
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def api_post(endpoint, key, payload=None, audio=None):
    headers = {"X-License-Key": key}
    if audio is not None:
        headers.update({"Content-Type": "application/octet-stream",
                        "Content-Disposition": 'attachment; filename="source.wav"',
                        "Content-Length": str(os.fstat(audio.fileno()).st_size)})
        body = audio
    else:
        headers["Content-Type"] = "application/json"
        body = json.dumps(payload).encode("utf-8")
    request = Request(API + endpoint, data=body, headers=headers, method="POST")
    try:
        with build_opener(NoRedirect()).open(request, timeout=300) as response:
            return json.load(response)
    except HTTPError as exc:
        exc.close()
        raise PipelineError(f"LALAL.AI {endpoint}: HTTP {exc.code}. Check API access, balance and request settings.") from None
    except (URLError, TimeoutError, OSError):
        raise PipelineError(f"Network failure at {endpoint}. A submitted job may still be running; use --task-id if available.") from None
    except ValueError:
        raise PipelineError("LALAL.AI returned invalid JSON.") from None


def wait_for_task(task_id, key, timeout):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        result = api_post("check/", key, {"task_ids": [task_id]})
        task = result.get("result", {}).get(task_id)
        if not isinstance(task, dict):
            raise PipelineError("Task missing from API response; it may have expired.")
        status = task.get("status")
        if status == "success":
            return task["result"]
        if status != "progress":
            raise PipelineError(f"Separation ended with status {status!r}.")
        print(f"Separation: {task.get('progress', 0)}%", flush=True)
        time.sleep(min(5, max(0, deadline - time.monotonic())))
    raise PipelineError(f"Polling timed out. Resume with --task-id {task_id}; the remote job is not cancelled.")


def guitar_url(result):
    matches = [t for t in result.get("tracks", [])
               if t.get("type") == "stem" and t.get("label") == "electric_guitar"]
    if len(matches) != 1:
        raise PipelineError("Expected exactly one electric_guitar stem in the result.")
    url = matches[0]["url"]
    if urlparse(url).scheme not in ("http", "https"):
        raise PipelineError("The result URL is not HTTP(S).")
    return url


def convert_to_wav(source, destination):
    try:
        subprocess.run(["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error",
                        "-n", "-i", str(source), "-map", "0:a:0", "-vn",
                        "-c:a", "pcm_s16le", str(destination)], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    except subprocess.CalledProcessError:
        raise PipelineError("FFmpeg could not decode the audio. Check the input file.") from None


def download_source(url, work):
    if urlparse(url).scheme not in ("http", "https"):
        raise PipelineError("Provide an HTTP(S) URL or use --input for a local file.")
    try:
        subprocess.run([sys.executable, "-m", "yt_dlp", "--ignore-config", "--no-playlist",
                        "--no-progress", "--quiet", "-f", "bestaudio/best",
                        "-o", str(work / "download.%(ext)s"), "--", url],
                       check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    except subprocess.CalledProcessError:
        raise PipelineError("URL download failed. Check the URL, install/update yt-dlp, or use --input with a local audio file.") from None
    files = [p for p in work.glob("download.*") if p.is_file() and p.suffix != ".part"]
    if len(files) != 1:
        raise PipelineError("Expected one downloaded media file.")
    return files[0]


def download_result(url, destination):
    # Separate request: never send the API key to a media download server.
    try:
        with urlopen(url, timeout=120) as response, destination.open("wb") as output:
            shutil.copyfileobj(response, output)
    except (URLError, TimeoutError, OSError):
        raise PipelineError("Result download failed. Resume using the printed task ID.") from None


def run(args):
    key = os.environ.get("LALAL_API_KEY", "").strip()
    if not key:
        raise PipelineError("Set the LALAL_API_KEY environment variable first (see README.md).")
    if shutil.which("ffmpeg") is None:
        raise PipelineError("FFmpeg is missing from PATH (see README.md).")
    output = args.output.expanduser().resolve()
    if output.suffix.lower() != ".wav":
        raise PipelineError("Output must have a .wav extension.")
    if output.exists():
        raise PipelineError("Output already exists. Choose another --output path.")
    if args.input and not args.input.is_file():
        raise PipelineError("Input file does not exist.")
    output.parent.mkdir(parents=True, exist_ok=True)
    # Same filesystem as output; intermediates are removed on success or failure.
    with tempfile.TemporaryDirectory(prefix=".guitar-", dir=output.parent) as directory:
        work = Path(directory)
        task_id = args.task_id
        if not task_id:
            print("Preparing source audio...", flush=True)
            source = args.input or download_source(args.url, work)
            wav = work / "source.wav"
            convert_to_wav(source, wav)
            print("Uploading audio to LALAL.AI...", flush=True)
            with wav.open("rb") as audio:
                source_id = api_post("upload/", key, audio=audio)["id"]
            print(f"Source ID: {source_id}", flush=True)
            # Queue choice is server-controlled; the public API has no Relaxed
            # selector. "auto" selects a model, not a queue (see README).
            task_id = api_post("split/stem_separator/", key, {
                "source_id": source_id,
                "presets": {"stem": "electric_guitar", "splitter": "auto",
                            "extraction_level": "deep_extraction"},
            })["task_id"]
        print(f"Task ID: {task_id} (save this to resume)", flush=True)
        result = wait_for_task(task_id, key, args.timeout)
        media = work / "result.audio"
        download_result(guitar_url(result), media)
        finished = work / "electric_guitar.wav"
        convert_to_wav(media, finished)
        # Exclusive creation prevents overwriting another process's output.
        with output.open("xb") as dest:
            try:
                with finished.open("rb") as src:
                    shutil.copyfileobj(src, dest)
            except BaseException:
                dest.close()
                output.unlink(missing_ok=True)
                raise
    print(f"Saved: {output}")


def main():
    parser = argparse.ArgumentParser(
        description=__doc__,
        epilog="Fast/Relaxed queue selection is controlled by LALAL.AI. "
               "There is no unlimited-mode flag; runs may consume Fast minutes. See README.md.",
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--url", help="Song/video URL supported by yt-dlp")
    source.add_argument("--input", type=Path, help="Local audio/video file")
    source.add_argument("--task-id", help="Resume an existing separation task")
    parser.add_argument("--output", type=Path, default=Path("outputs/electric_guitar.wav"))
    parser.add_argument("--timeout", type=float, default=1800,
                        help="Polling deadline in seconds (default: 1800)")
    args = parser.parse_args()
    if not math.isfinite(args.timeout) or args.timeout <= 0:
        parser.error("--timeout must be a finite positive number")
    try:
        run(args)
    except (PipelineError, OSError, KeyError, TypeError) as exc:
        message = str(exc) if isinstance(exc, PipelineError) else "File operation failed or API response had an unexpected format."
        print(f"Error: {message}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("Stopped locally. A submitted remote task may still run; resume with its task ID.", file=sys.stderr)
        return 130
    return 0


if __name__ == "__main__":
    sys.exit(main())
