import argparse
import io
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
import wave

import guitar_pipeline as pipeline


class PipelineTests(unittest.TestCase):
    def test_selects_guitar_not_backing(self):
        result = {"tracks": [
            {"type": "back", "label": "no_electric_guitar", "url": "https://example.com/back"},
            {"type": "stem", "label": "electric_guitar", "url": "https://example.com/guitar"}]}
        self.assertEqual(pipeline.guitar_url(result), "https://example.com/guitar")
        with self.assertRaises(pipeline.PipelineError):
            pipeline.guitar_url({"tracks": result["tracks"][:1]})

    def test_poll_progress_then_success(self):
        replies = [{"result": {"task": {"status": "progress", "progress": 40}}},
                   {"result": {"task": {"status": "success", "result": {"tracks": []}}}}]
        with patch.object(pipeline, "api_post", side_effect=replies) as post, patch.object(pipeline.time, "sleep"):
            self.assertEqual(pipeline.wait_for_task("task", "test-key", 30), {"tracks": []})
            post.assert_called_with("check/", "test-key", {"task_ids": ["task"]})

    def test_terminal_states_fail(self):
        for status in ("cancelled", "error", "server_error", "unexpected"):
            with self.subTest(status=status), patch.object(pipeline, "api_post", return_value={"result": {"task": {"status": status}}}):
                with self.assertRaises(pipeline.PipelineError):
                    pipeline.wait_for_task("task", "test-key", 30)

    def test_timeout_does_not_submit(self):
        with patch.object(pipeline, "api_post") as post:
            with self.assertRaisesRegex(pipeline.PipelineError, "--task-id task"):
                pipeline.wait_for_task("task", "test-key", 0)
            post.assert_not_called()

    def test_auth_header_and_json_body(self):
        with patch.object(pipeline, "build_opener") as opener:
            opener.return_value.open.return_value = io.BytesIO(b'{"task_id":"task"}')
            self.assertEqual(pipeline.api_post("check/", "test-key", {"task_ids": ["task"]}), {"task_id": "task"})
            request = opener.return_value.open.call_args.args[0]
            self.assertEqual(request.get_header("X-license-key"), "test-key")
            self.assertEqual(json.loads(request.data), {"task_ids": ["task"]})

    def test_http_errors_do_not_echo_secrets(self):
        with patch.object(pipeline, "build_opener") as opener:
            opener.return_value.open.side_effect = HTTPError(pipeline.API, 403, "test-key", {}, None)
            with self.assertRaises(pipeline.PipelineError) as error:
                pipeline.api_post("check/", "test-key", {})
            self.assertNotIn("test-key", str(error.exception))

    def test_missing_key_fails_before_network(self):
        with patch.dict(os.environ, {}, clear=True), patch.object(pipeline, "api_post") as post:
            with self.assertRaisesRegex(pipeline.PipelineError, "LALAL_API_KEY"):
                pipeline.run(argparse.Namespace())
            post.assert_not_called()

    @unittest.skipUnless(shutil.which("ffmpeg"), "FFmpeg not installed")
    def test_local_pipeline_and_resume(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "input.wav"
            with wave.open(str(source), "wb") as wav:
                wav.setparams((1, 2, 8000, 0, "NONE", "not compressed"))
                wav.writeframes(b"\x00\x00" * 800)
            result = {"tracks": [{"type": "stem", "label": "electric_guitar", "url": "https://example.com/stem"}]}
            for resume in (False, True):
                output = root / f"result-{resume}.wav"
                args = argparse.Namespace(input=source, url=None, task_id="task" if resume else None,
                                          output=output, timeout=30)
                responses = [] if resume else [{"id": "source"}, {"task_id": "task"}]
                responses.append({"result": {"task": {"status": "success", "result": result}}})
                with patch.dict(os.environ, {"LALAL_API_KEY": "test-key"}), patch.object(pipeline, "api_post", side_effect=responses) as post, patch.object(pipeline, "download_result", side_effect=lambda url, path: shutil.copyfile(source, path)):
                    pipeline.run(args)
                    self.assertEqual(post.call_count, 1 if resume else 3)
                    if not resume:
                        self.assertEqual(post.call_args_list[1].args[2]["presets"]["stem"], "electric_guitar")
                with wave.open(str(output)) as wav:
                    self.assertEqual(wav.getnframes(), 800)
                self.assertFalse(list(root.glob(".guitar-*")))


if __name__ == "__main__":
    unittest.main()
